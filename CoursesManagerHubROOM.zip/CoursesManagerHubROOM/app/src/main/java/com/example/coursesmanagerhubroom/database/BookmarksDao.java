package com.example.coursesmanagerhubroom.database;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface BookmarksDao {


    @Insert
    long insertBookmark(Bookmarks bookmark);

    @Update
    void updateBookmarks(Bookmarks bookmark);

    @Delete
    int deleteBookmarks(Bookmarks bookmark);

    @Query("SELECT * FROM Bookmarks")
    List<Bookmarks> getAllBookmarks();


    @Query("SELECT * FROM bookmarks WHERE user_id = :user_id")
    List<Bookmarks> getBookmarksForUser(long user_id);


}
