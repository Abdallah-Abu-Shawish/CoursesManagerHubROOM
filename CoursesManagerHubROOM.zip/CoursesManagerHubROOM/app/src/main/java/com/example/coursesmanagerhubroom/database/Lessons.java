package com.example.coursesmanagerhubroom.database;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.PrimaryKey;

@Entity(foreignKeys = @ForeignKey(entity = Courses.class,parentColumns = {"id"},childColumns = {"course_id"},onDelete = 1,onUpdate = 1))
public class Lessons {
    @PrimaryKey(autoGenerate = true)
    private long lesson_id;
    @NonNull
    private String lesson_title;
    @NonNull
    private String lesson_details;
    @NonNull
    private String lesson_link;
    @NonNull
    private int lesson_number;
    @NonNull
    private long course_id;

    public Lessons(@NonNull String lesson_title, @NonNull String lesson_details, @NonNull String lesson_link, int lesson_number, long course_id) {
        this.lesson_title = lesson_title;
        this.lesson_details = lesson_details;
        this.lesson_link = lesson_link;
        this.lesson_number = lesson_number;
        this.course_id = course_id;
    }

    public long getLesson_id() {
        return lesson_id;
    }

    public void setLesson_id(long lesson_id) {
        this.lesson_id = lesson_id;
    }

    @NonNull
    public String getLesson_title() {
        return lesson_title;
    }

    public void setLesson_title(@NonNull String lesson_title) {
        this.lesson_title = lesson_title;
    }

    @NonNull
    public String getLesson_details() {
        return lesson_details;
    }

    public void setLesson_details(@NonNull String lesson_details) {
        this.lesson_details = lesson_details;
    }

    @NonNull
    public String getLesson_link() {
        return lesson_link;
    }

    public void setLesson_link(@NonNull String lesson_link) {
        this.lesson_link = lesson_link;
    }

    public int getLesson_number() {
        return lesson_number;
    }

    public void setLesson_number(int lesson_number) {
        this.lesson_number = lesson_number;
    }

    public long getCourse_id() {
        return course_id;
    }

    public void setCourse_id(long course_id) {
        this.course_id = course_id;
    }
}
