package com.example.coursesmanagerhubroom.database;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.PrimaryKey;

@Entity(foreignKeys = @ForeignKey(entity = Users.class, parentColumns = {"id"}, childColumns = {"userIn_id"}))
public class UserIn {
    @PrimaryKey(autoGenerate = true)
    private long _id;
    @NonNull
    private long userIn_id;
    private String userIn_email;




    public UserIn(@NonNull long userIn_id, @NonNull String userIn_email) {
        this.userIn_id = userIn_id;
        this.userIn_email = userIn_email;
    }

    public long get_id() {
        return _id;
    }

    public void set_id(long _id) {
        this._id = _id;
    }

    public long getUserIn_id() {
        return userIn_id;
    }


    public void setUserIn_id(long userIn_id) {
        this.userIn_id = userIn_id;
    }


    public String getUserIn_email() {
        return userIn_email;
    }

    public void setUserIn_email(String userIn_email) {
        this.userIn_email = userIn_email;
    }
}
