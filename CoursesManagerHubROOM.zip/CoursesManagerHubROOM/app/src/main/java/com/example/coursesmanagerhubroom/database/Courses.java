package com.example.coursesmanagerhubroom.database;

import android.net.Uri;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.PrimaryKey;

@Entity(foreignKeys = @ForeignKey(entity = Categories.class,parentColumns = {"cat_id"},childColumns = {"category_id"},onUpdate = 1,onDelete = 1))
public class Courses {
    @PrimaryKey(autoGenerate = true)
    private long id;
    @NonNull
    private String course_name;
    private Uri course_image;
    @NonNull
    private String instructor_name;
    @NonNull
    private float course_price;

    private int students_number;
    @NonNull
    private int hours_number;
    @NonNull
    private String course_details;

    private int lessons_number;
    @NonNull
    private long category_id;

    public Courses(@NonNull String course_name, Uri course_image, @NonNull String instructor_name, float course_price, int students_number, int hours_number, @NonNull String course_details, int lessons_number, long category_id) {
        this.course_name = course_name;
        this.course_image = course_image;
        this.instructor_name = instructor_name;
        this.course_price = course_price;
        this.students_number = students_number;
        this.hours_number = hours_number;
        this.course_details = course_details;
        this.lessons_number = lessons_number;
        this.category_id = category_id;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    @NonNull
    public String getCourse_name() {
        return course_name;
    }

    public void setCourse_name(@NonNull String course_name) {
        this.course_name = course_name;
    }

    public Uri getCourse_image() {
        return course_image;
    }

    public void setCourse_image(Uri course_image) {
        this.course_image = course_image;
    }

    @NonNull
    public String getInstructor_name() {
        return instructor_name;
    }

    public void setInstructor_name(@NonNull String instructor_name) {
        this.instructor_name = instructor_name;
    }

    public float getCourse_price() {
        return course_price;
    }

    public void setCourse_price(float course_price) {
        this.course_price = course_price;
    }

    public int getStudents_number() {
        return students_number;
    }

    public void setStudents_number(int students_number) {
        this.students_number = students_number;
    }

    public int getHours_number() {
        return hours_number;
    }

    public void setHours_number(int hours_number) {
        this.hours_number = hours_number;
    }

    @NonNull
    public String getCourse_details() {
        return course_details;
    }

    public void setCourse_details(@NonNull String course_details) {
        this.course_details = course_details;
    }

    public int getLessons_number() {
        return lessons_number;
    }

    public void setLessons_number(int lessons_number) {
        this.lessons_number = lessons_number;
    }

    public long getCategory_id() {
        return category_id;
    }

    public void setCategory_id(long category_id) {
        this.category_id = category_id;
    }
}
