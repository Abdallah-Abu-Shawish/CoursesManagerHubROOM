package com.example.coursesmanagerhubroom.database;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;
@Dao
public interface UsersDao {

    @Insert
    long insertUser(Users user);

    @Update
    void updateUser(Users user);

    @Delete
    int deleteUser(Users user);

    @Query("SELECT * FROM Users")
    List<Users> getAllUsers();


    @Query("SELECT * FROM Users WHERE id = :id")
    Users getUser(long id);

    @Query("SELECT * FROM Users WHERE username = :username")
    Users getUserByUsername(String username);

    @Query("SELECT * FROM Users WHERE email = :email")
    Users getUserByEmail(String email);
    @Query("SELECT * FROM Users WHERE email =:email AND password =:password")
    Users getUser(String email ,String password);

}
