package com.example.coursesmanagerhubroom.database;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface NotificationsDao {

    @Insert
    long insertNotifications(Notifications notification);

    @Update
    void updateNotifications(Notifications notification);

    @Delete
    int deleteNotifications(Notifications notification);

    @Query("SELECT * FROM Notifications")
    List<Notifications> getAllNotifications();

    @Query("SELECT * FROM Notifications WHERE Notifications.course_id = :course_id")
    List<Notifications> getAllNotificationsForCourse(long course_id);

    @Query("SELECT * FROM Notifications WHERE Notifications.user_id = :user_id")
    List<Notifications> getAllNotificationsForUser(long user_id);
}
