package com.example.coursesmanagerhubroom.database;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity
public class Categories {
    @PrimaryKey(autoGenerate = true)
    private long cat_id;
    @NonNull
    private String category_name;

    public Categories(long cat_id, @NonNull String category_name) {
        this.cat_id = cat_id;
        this.category_name = category_name;
    }

    @NonNull
    public String getCategory_name() {
        return category_name;
    }

    public void setCategory_name(@NonNull String category_name) {
        this.category_name = category_name;
    }

    public long getCat_id() {
        return cat_id;
    }

    public void setCat_id(long cat_id) {
        this.cat_id = cat_id;
    }
}
