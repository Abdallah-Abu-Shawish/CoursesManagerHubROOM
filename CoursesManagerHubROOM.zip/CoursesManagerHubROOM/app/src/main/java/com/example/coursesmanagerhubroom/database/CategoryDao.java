package com.example.coursesmanagerhubroom.database;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface CategoryDao {
    @Insert
    long insertCategory(Categories category);

    @Update
    void updateCategory(Categories category);

    @Delete
    int deleteCategory(Categories category);

    @Query("SELECT * FROM Categories")
    List<Categories> getAllCategories();
}
