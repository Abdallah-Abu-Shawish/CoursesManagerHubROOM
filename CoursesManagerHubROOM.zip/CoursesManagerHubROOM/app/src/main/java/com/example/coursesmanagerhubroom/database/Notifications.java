package com.example.coursesmanagerhubroom.database;

import androidx.room.Entity;
import androidx.room.ForeignKey;

@Entity(foreignKeys ={ @ForeignKey(entity = Users.class,parentColumns = {"id"},childColumns = {"user_id"},onUpdate = 1,onDelete = 1)
        ,@ForeignKey(entity = Courses.class,parentColumns = {"id"},childColumns = {"course_id"},onDelete = 1,onUpdate = 1)})
public class Notifications {
    private long id;
    private long user_id;
    private long course_id;
    private String message;
    private String type;

    public Notifications(long user_id, long course_id, String message, String type) {
        this.user_id = user_id;
        this.course_id = course_id;
        this.message = message;
        this.type = type;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public long getUser_id() {
        return user_id;
    }

    public void setUser_id(long user_id) {
        this.user_id = user_id;
    }

    public long getCourse_id() {
        return course_id;
    }

    public void setCourse_id(long course_id) {
        this.course_id = course_id;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}
