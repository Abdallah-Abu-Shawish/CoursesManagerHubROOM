package com.example.coursesmanagerhubroom.database;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;
@Dao
public interface CoursesDao {


    @Insert
    long insertCourses(Courses course);

    @Update
    void updateCourses(Courses course);

    @Delete
    int deleteCourses(Courses course);

    @Query("SELECT * FROM Courses")
    List<Courses> getAllCourses();


    @Query("SELECT * FROM Courses WHERE category_id = :cat_id")
    List<Courses> getAllCoursesForCategory(long cat_id);


}
