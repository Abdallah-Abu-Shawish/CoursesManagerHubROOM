package com.example.coursesmanagerhubroom.database;

import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.PrimaryKey;

@Entity(foreignKeys ={ @ForeignKey(entity = Users.class,parentColumns = {"id"},childColumns = {"user_id"},onUpdate = 1,onDelete = 1)
        ,@ForeignKey(entity = Courses.class,parentColumns = {"id"},childColumns = {"course_id"},onDelete = 1,onUpdate = 1)})
public class User_Courses {
    @PrimaryKey(autoGenerate = true)
    private long id;
    private long user_id;
    private long course_id;
    private int user_progress;
    private boolean course_states;


    public User_Courses(long user_id, long course_id) {
        this.user_id = user_id;
        this.course_id = course_id;
        this.user_progress = 0;
        this.course_states = false;
    }

    public boolean isCourse_states() {
        return course_states;
    }

    public void setCourse_states(boolean course_states) {
        this.course_states = course_states;
    }

    public int getUser_progress() {
        return user_progress;
    }

    public void setUser_progress(int user_progress) {
        this.user_progress = user_progress;
    }

    public long getCourse_id() {
        return course_id;
    }

    public void setCourse_id(long course_id) {
        this.course_id = course_id;
    }

    public long getUser_id() {
        return user_id;
    }

    public void setUser_id(long user_id) {
        this.user_id = user_id;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }
}
