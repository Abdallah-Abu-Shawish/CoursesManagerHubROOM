package com.example.coursesmanagerhubroom.database;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface User_CoursesDao {

    @Insert
    long insertUser_Courses(User_Courses userCourse);

    @Update
    void updateUser_Courses(User_Courses userCourse);

    @Delete
    int deleteUser_Courses(User_Courses userCourse);

    @Query("SELECT * FROM User_Courses")
    List<User_Courses> getAllUserCourses();

    @Query("SELECT * FROM User_Courses WHERE User_Courses.user_id = :user_id")
    List<User_Courses> getAllUserCourses(long user_id);


}
