package com.example.coursesmanagerhubroom.database;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface LessonsDao {


    @Insert
    long insertLessons(Lessons lesson);

    @Update
    void updateLessons(Lessons lesson);

    @Delete
    int deleteLessons(Lessons lesson);

    @Query("SELECT * FROM Lessons")
    List<Lessons> getAllLessons();

    @Query("SELECT * FROM Lessons WHERE course_id = :course_id")
    List<Lessons> getAllLessonsForCourse(long course_id);

}
